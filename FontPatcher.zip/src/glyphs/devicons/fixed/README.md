This folder contains some modified icons, where the 2.16.0 svg file of Devicons had some import problem.

These files will be preferred over the filenames specified in the mapping file.

Be careful on Devicon updates.
