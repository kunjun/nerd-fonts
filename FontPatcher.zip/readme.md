
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 14623173e265c868ffe9c59f829591238f055b66
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Feb 21 11:56:39 2025 +0100
        
            font-patcher: Add debug output with some center coordinates
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
