
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit c0f0c70de8d5ccd6c386bfa1b2042da1f58db2d7
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed Jan 8 20:39:55 2025 +0100
        
            font-patcher: Comment on maybe strange looking code
            
            [why]
            I again had to look the reason for the code up, which just looks
            strange. Who expects that a bool is an instance of int? I certainly not.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
