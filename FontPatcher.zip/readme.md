
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 30a9b82eff643f0b95af3ae127b84fd8b8a520d9
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Jun 6 15:37:24 2025 +0200
        
            font-patcher: Fix patching of fonts with slashes in name
            
            [why]
            When trying to patch Anka/Coder fontforge reports it can not open the
            font file.
            
            [how]
            When opening a font file we open all fonts within that file. For a ttf
            or otf that is one font, but ttc can contain multiple fonts (of course).
            
            The fontforge open function takes the font filename and the subfont name
            in parenteses appended to the font filename. For example
            `directory/folder/myfont.ttf` which contains just MyFont, it opens via
            `directory/folder/myfont.ttf(MyFont)`.
            
            That algorithm is not very smart, and so this fails
            `directory/folder/AnkaCoder-r.ttf(Anka/Coder)` because it assumes the
            directory goes up to the last slash and takes `Coder)` as filename.
            
            But instead of using the concrete subfont name we can also specify the
            index of the subfont in the font file, and that circumvents the problem.
            
            [note]
            The TTC opening feature is not well documented in Fontforge, best
            described here:
            https://fontforge.org/docs/ui/menus/filemenu.html#the-file-menu
            
            Fixes: #1879
            
            Reported-by: @oktoling
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
