
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit ebc376cbd43f609d8084f47dd348646595ce066e
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue May 6 12:46:27 2025 +0200
        
            DejaVuSansMono: Fix monospaced (and remove subdirs)
            
            [why]
            The original / upstream version of DejaVuSansMono does not have the
            trigrams at codepoint U+2630 - U+2637. These have been added manually
            (together with some Powerline glyphs) with commit
            
                bc1f35949 Updates DejaVu fonts from version 2.33 to 2.37 & adds trigrams (2630 through 2627) (fixes #100)
            
            Unfortunately the newly added glyphs were just copied over from
            DejaVuSansCondensed and the width does not match the monospaced width of
            DejaVuSansMono: the resulting font is not monospaced anymore (but it
            should be, by its name part Mono).
            
            [how]
            Take the glyphs again from DejaVuSansCondensed but instead of directly
            transferring:
             - export glyphs as svg from Condensed font
             - in the Mono font set the width of the empty target glyphs to 1233
             - import the svgs
             - scale the glyphs X to 75% (100% in Y)
             - center the glyphs within the width
            
            The exact same glyphs have been used for all 4 fonts.
            
            [note]
            Also remove the subdir structure as this is the new way to hold the font
            files. Remember to clean the patched-fonts/ directory up before release.
            
            Fixes: #1864
            
            Reported-by: @pmadzik
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
