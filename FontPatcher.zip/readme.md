
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit fa7c3b9b3a2ea15e9195b626a2089eb3462afcfb
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Sat Jun 7 16:58:30 2025 +0200
        
            docs: add mietzen as a contributor for bug (#1883)
            
            * docs: update CONTRIBUTORS.md
            
            * docs: update .all-contributorsrc
            
            ---------
            
            Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
